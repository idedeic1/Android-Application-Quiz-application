package ba.unsa.etf.rma;

import android.content.Context;
import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.List;

import aktivnosti.unsa.etf.rma.R;

public class OdgovorAdapter extends ArrayAdapter<String> {
    private int resource;
    private Context context;
    private String tacan;
    public OdgovorAdapter( Context context, int resource,  List<String> objects) {
        super(context, resource, objects);
        this.resource = resource;
        this.context = context;
        this.tacan = tacan;
    }


    @Override
    public View getView(int position,  View convertView, ViewGroup parent) {

        LinearLayout view=null;
        if(convertView==null){
            view = new LinearLayout(getContext());
            String inflater = Context.LAYOUT_INFLATER_SERVICE;
            LayoutInflater li;
            li = (LayoutInflater)getContext().
                    getSystemService(inflater);
            li.inflate(resource, view, true);
        }else{
            view = (LinearLayout) convertView;
        }

        String odgovor = getItem(position);
        if (odgovor.equals(tacan)) {
            view.setBackgroundColor(Color.GREEN);
        }
        TextView text = view.findViewById(R.id.kvizText);
        ImageView ikona = view.findViewById(R.id.kvizIcon);

        text.setText(odgovor);
        ikona.setImageResource(android.R.drawable.btn_radio);

        return view;
    }
    public void setTacan(String t){
        tacan=t;
    }
}
