package ba.unsa.etf.rma;

import android.content.Context;

public class Request {
    Context context;
    String type;
    String URL;
}
