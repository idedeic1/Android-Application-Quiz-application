package ba.unsa.etf.rma.aktivnosti;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.support.v7.app.AppCompatActivity;
import android.widget.Button;
import android.widget.EditText;

import com.maltaisn.icondialog.Icon;
import com.maltaisn.icondialog.IconDialog;

import aktivnosti.unsa.etf.rma.R;
import ba.unsa.etf.rma.MyResultReceiver;
import ba.unsa.etf.rma.klase.Kategorija;
import ba.unsa.etf.rma.tasks.FireService;

public class DodajKategorijuAkt extends AppCompatActivity implements IconDialog.Callback, MyResultReceiver.Receiver {

    Icon[] selectedIcons;
    private EditText etNaziv;
    private EditText etIkona;
    private Button btnDodajIkonu;
    private Button btnDodajKategoriju;
    private MyResultReceiver myResultReceiver;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dodaj_kategoriju_akt);

        btnDodajIkonu = findViewById(R.id.btnDodajIkonu);
        etNaziv = findViewById(R.id.etNaziv);
        etIkona = findViewById(R.id.etIkona);
        btnDodajKategoriju = findViewById(R.id.btnDodajKategoriju);
        myResultReceiver = new MyResultReceiver(new Handler());
        myResultReceiver.setReceiver(this);

        final IconDialog iconDialog = new IconDialog();

        btnDodajIkonu.setOnClickListener(v -> {
            iconDialog.setSelectedIcons(selectedIcons);
            iconDialog.show(getSupportFragmentManager(), "icon_dialog");

        });
        btnDodajKategoriju.setOnClickListener(v -> {
            if(etIkona.getText()!=null
                    && !etIkona.getText().toString().equals("")
                    && etNaziv.getText()!=null
                    && !etNaziv.getText().toString().equals("")){
                System.out.println("posting???");
                postToService();

            }
        });

    }

    private void postToService() {
        Intent intent = new Intent(Intent.ACTION_SYNC,null,this, FireService.class);
        intent.putExtra("name","Kategorije");
        intent.putExtra("method","PATCH");
        System.out.println(" "+etNaziv.getText()+" "+etIkona.getText());
        Bundle bundle = new Bundle();
        bundle.putSerializable("kategorija",new Kategorija(etNaziv.getText().toString(),etIkona.getText().toString()));
        intent.putExtras(bundle);
        intent.putExtra("receiver", myResultReceiver);
        startService(intent);
    }

    @Override
    public void onIconDialogIconsSelected(Icon[] icons) {
        selectedIcons = icons;
        int id = icons[0].getId();
        etIkona.setText(Integer.toString(id));
    }

    @Override
    public void onRecieveResult(int resultCode, Bundle resultData) {
        if(resultCode == FireService.STATUS_FINISHED){
            System.out.println("It happened");
            Intent success = new Intent(this, DodajKvizAkt.class);
            setResult(RESULT_OK, success);
            finish();
        }else{
            etNaziv.setBackgroundColor(Color.RED);
        }
    }
}
