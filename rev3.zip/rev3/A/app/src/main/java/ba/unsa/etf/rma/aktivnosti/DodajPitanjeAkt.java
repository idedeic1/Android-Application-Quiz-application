package ba.unsa.etf.rma.aktivnosti;

import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;

import java.util.ArrayList;

import aktivnosti.unsa.etf.rma.R;
import ba.unsa.etf.rma.OdgovorAdapter;
import ba.unsa.etf.rma.klase.Pitanje;

public class DodajPitanjeAkt extends AppCompatActivity {

    Button dodajPitanje;
    Button dodajTacan;
    Button dodajOdgovor;
    EditText etOdgovor;
    ListView lvOdgovori;
    EditText etNaziv;
    View.OnClickListener dodajListener;
    View.OnClickListener dodajOdgovorListener;
    View.OnClickListener dodajTacanListener;
    AdapterView.OnItemClickListener itemListener;
    ArrayList<String> odgovori;
    private Pitanje pitanje;
    private String tacan="";
    Drawable editTextBackground;

    public String getTacan(){
        if(pitanje!=null && pitanje.getTacan()!=null){
            return pitanje.getTacan();
        }
        return "";
    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dodaj_pitanje_akt);
        init();
        dodajOdgovor.setOnClickListener(dodajOdgovorListener);
        dodajTacan.setOnClickListener(dodajTacanListener);
        dodajPitanje.setOnClickListener(dodajListener);
        lvOdgovori.setOnItemClickListener(itemListener);

    }

    private void init() {
        odgovori = new ArrayList<>();
        pitanje = new Pitanje();
        pitanje.setTacan("");
        dodajPitanje = findViewById(R.id.btnDodajPitanje);
        dodajTacan = findViewById(R.id.btnDodajTacan);
        dodajOdgovor = findViewById(R.id.btnDodajOdgovor);
        etNaziv = findViewById(R.id.etNaziv);
        etOdgovor = findViewById(R.id.etOdgovor);
        lvOdgovori = findViewById(R.id.lvOdgovori);
        editTextBackground = etNaziv.getBackground();


        final OdgovorAdapter odgovorAdapter = new OdgovorAdapter(this, R.layout.kviz_cell, odgovori);
        lvOdgovori.setAdapter(odgovorAdapter);

        dodajListener = v -> {
            if(!pitanje.getTacan().equals("") && !etNaziv.getText().toString().equals("")){
                pitanje.setNaziv(etNaziv.getText().toString());
                pitanje.setTekstPitanja(etNaziv.getText().toString());
                pitanje.setOdgovori(odgovori);
                Intent intent = new Intent(DodajPitanjeAkt.this, DodajKvizAkt.class);
                Bundle bundle = new Bundle();
                bundle.putSerializable("pitanje",pitanje);
                intent.putExtras(bundle);
                setResult(RESULT_OK,intent);
                finish();
            }
            if(etNaziv.getText().toString().equals(""))etNaziv.setBackgroundColor(Color.RED);

        };
        dodajTacanListener = v -> {
            if (pitanje.getTacan().equals("") && !etOdgovor.getText().toString().equals("")) {
                String provjera = etOdgovor.getText().toString();
                if(!odgovori.contains(provjera)) {
                    odgovori.add(etOdgovor.getText().toString());
                    pitanje.setTacan(etOdgovor.getText().toString());
                    tacan = etOdgovor.getText().toString();
                    odgovorAdapter.setTacan(tacan);
                    odgovorAdapter.notifyDataSetChanged();
                }else{
                    etOdgovor.setBackgroundColor(Color.RED);
                }
                etOdgovor.setText("");
            }else{
                etOdgovor.setBackgroundColor(Color.RED);
            }
        };
        dodajOdgovorListener = v -> {
            if (!etOdgovor.getText().toString().equals("")) {
                String provjera = etOdgovor.getText().toString();
                if(!odgovori.contains(provjera)) {
                    odgovori.add(etOdgovor.getText().toString());
                    odgovorAdapter.notifyDataSetChanged();
                    etOdgovor.setBackground(editTextBackground);
                }
                etOdgovor.setText("");
            } else {
                etOdgovor.setBackgroundColor(Color.RED);
            }
        };
        itemListener = (parent, view, position, id) -> {
            if(odgovori.get(position).equals(pitanje.getTacan())){
                pitanje.setTacan("");
                tacan="";
                odgovorAdapter.setTacan(tacan);
            }
            odgovori.remove(position);
            odgovorAdapter.notifyDataSetChanged();
        };
    }
}
