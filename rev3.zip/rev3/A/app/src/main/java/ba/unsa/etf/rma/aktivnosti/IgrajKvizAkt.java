package ba.unsa.etf.rma.aktivnosti;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.support.v4.app.FragmentActivity;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;

import java.util.ArrayList;
import java.util.Collections;

import aktivnosti.unsa.etf.rma.R;
import ba.unsa.etf.rma.fragmenti.InformacijeFrag;
import ba.unsa.etf.rma.fragmenti.PitanjeFrag;
import ba.unsa.etf.rma.klase.Kviz;
import ba.unsa.etf.rma.klase.Pitanje;

public class IgrajKvizAkt extends FragmentActivity
                                implements InformacijeFrag.OnFragmentInteractionListener
                                , PitanjeFrag.OnFragmentInteractionListener{

    private Kviz kviz;
    private InformacijeFrag informacijeFragment;
    private PitanjeFrag pitanjeFragment;

    private ArrayList<Pitanje> pitanja;
    private Pitanje trenutnoPitanje=null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_igraj_kviz_akt);

        kviz = (Kviz) getIntent().getExtras().getSerializable("kviz");
        pitanja = new ArrayList<>();
        if(kviz.getPitanja()!=null)pitanja.addAll(kviz.getPitanja());
        try {
            useNextRandomPitanje();
        } catch (Exception e) {
            ArrayList<String> odgovori = new ArrayList<>();
            Pitanje pitanje = new Pitanje("Kviz je završen!","Kviz je završen!",odgovori,"");
            trenutnoPitanje = pitanje;
        }
        informacijeFragment = InformacijeFrag.newInstance(kviz);
        pitanjeFragment = PitanjeFrag.newInstance(trenutnoPitanje);
        FragmentManager fragmentManager = getSupportFragmentManager();
        FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
        fragmentTransaction.add(R.id.informacijePlace, informacijeFragment);
        fragmentTransaction.add(R.id.pitanjePlace, pitanjeFragment);
        fragmentTransaction.commit();

    }

    private void useNextRandomPitanje() {
        Collections.shuffle(pitanja);
        trenutnoPitanje = pitanja.get(0);
        pitanja.remove(0);
    }

    @Override
    public void nextQuestion(Boolean answeredRight) {
        try {
            informacijeFragment.proceed(answeredRight);
            useNextRandomPitanje();
            final PitanjeFrag newPitanjeFragment = PitanjeFrag.newInstance(trenutnoPitanje);
            final Handler handler = new Handler();
            handler.postDelayed(new Runnable() {
                @Override
                public void run() {
                    //Do something after 100ms
                    try {
                        FragmentManager fragmentManager = getSupportFragmentManager();
                        FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
                        fragmentTransaction.replace(R.id.pitanjePlace, newPitanjeFragment);
                        fragmentTransaction.commit();
                    } catch (Exception e) {
                        finish();
                    }
                }
            }, 2000);
        } catch (Exception kvizFinished) {
            ArrayList<String> odgovori = new ArrayList<>();
            Pitanje pitanje = new Pitanje("Kviz je završen!","Kviz je završen!",odgovori,"");
            final PitanjeFrag newPitanjeFragment = PitanjeFrag.newInstance(pitanje);
            final Handler handler = new Handler();
            handler.postDelayed(new Runnable() {
                @Override
                public void run() {
                    //Do something after 100ms
                    try {
                        FragmentManager fragmentManager = getSupportFragmentManager();
                        FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
                        fragmentTransaction.replace(R.id.pitanjePlace, newPitanjeFragment);
                        fragmentTransaction.commit();
                    } catch (Exception e) {
                        finish();
                    }
                }
            }, 2000);
        }
    }

    @Override
    public void endGame() {
        Intent intent = new Intent(IgrajKvizAkt.this, KvizoviAkt.class);
        setResult(RESULT_OK, intent);
        finish();
    }
}
