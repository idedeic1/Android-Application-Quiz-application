package ba.unsa.etf.rma.fragmenti;

import android.content.Context;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;

import aktivnosti.unsa.etf.rma.R;
import ba.unsa.etf.rma.klase.Pitanje;


/**
 * A simple {@link Fragment} subclass.
 * Activities that contain this fragment must implement the
 * {@link PitanjeFrag.OnFragmentInteractionListener} interface
 * to handle interaction events.
 * Use the {@link PitanjeFrag#newInstance} factory method to
 * create an instance of this fragment.
 */
public class PitanjeFrag extends Fragment {
    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER

    private TextView tekstPitanjaField;
    private ListView listOdgovori;
    private ArrayAdapter<String> odgovorAdapter;
    private ArrayList<String> odgovori;

    private OnFragmentInteractionListener mListener;
    private Pitanje pitanje;


    public PitanjeFrag() {
        // Required empty public constructor
    }

    public static PitanjeFrag newInstance(Pitanje pitanje) {
        PitanjeFrag fragment = new PitanjeFrag();
        Bundle args = new Bundle();
        args.putSerializable("pitanje",pitanje);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            pitanje = (Pitanje) getArguments().getSerializable("pitanje");
        }
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        tekstPitanjaField = getActivity().findViewById(R.id.tekstPitanja);
        listOdgovori = getActivity().findViewById(R.id.odgovoriPitanja);
        tekstPitanjaField.setText(pitanje.getTekstPitanja());
        odgovori = new ArrayList<>();
        odgovori.addAll(pitanje.dajRandomOdgovore());
        odgovorAdapter = new ArrayAdapter<String>(getContext(),android.R.layout.simple_list_item_1,odgovori);
        listOdgovori.setAdapter(odgovorAdapter);
        listOdgovori.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                View child = parent.getChildAt(position);
                Boolean rightAnswer = false;
                if (odgovori.get(position).equals(pitanje.getTacan())) {
                    child.setBackgroundColor(getResources().getColor(R.color.zelena));
                    rightAnswer = true;
                }else{
                    child.setBackgroundColor(getResources().getColor(R.color.crvena));
                }
                listOdgovori.setClickable(false);
                listOdgovori.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                    @Override
                    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

                    }
                });
                mListener.nextQuestion(rightAnswer);
            }
        });
        super.onViewCreated(view, savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_pitanje, container, false);
    }



    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if (context instanceof OnFragmentInteractionListener) {
            mListener = (OnFragmentInteractionListener) context;
        } else {
            throw new RuntimeException(context.toString()
                    + " must implement OnFragmentInteractionListener");
        }
    }

    @Override
    public void onDetach() {
        super.onDetach();
        mListener = null;
    }


    public interface OnFragmentInteractionListener {


        void nextQuestion(Boolean rightAnswer);
    }
}
