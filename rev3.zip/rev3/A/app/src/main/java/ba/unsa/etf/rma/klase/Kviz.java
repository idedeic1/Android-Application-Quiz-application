package ba.unsa.etf.rma.klase;

import android.os.Parcel;
import android.os.Parcelable;

import java.io.Serializable;
import java.util.ArrayList;

public class Kviz implements Parcelable, Serializable {
    private String naziv;
    private ArrayList<Pitanje> pitanja;
    private Kategorija kategorija;

    public Kviz() {
    }

    public Kviz(String naziv, ArrayList<Pitanje> pitanja, Kategorija kategorija) {
        this.naziv = naziv;
        this.pitanja = pitanja;
        this.kategorija = kategorija;
    }

    protected Kviz(Parcel in) {
        naziv = in.readString();
        pitanja = in.createTypedArrayList(Pitanje.CREATOR);
        kategorija = in.readParcelable(Kategorija.class.getClassLoader());
    }

    public static final Creator<Kviz> CREATOR = new Creator<Kviz>() {
        @Override
        public Kviz createFromParcel(Parcel in) {
            return new Kviz(in);
        }

        @Override
        public Kviz[] newArray(int size) {
            return new Kviz[size];
        }
    };

    public String getNaziv() {
        if(naziv==null) return "";
        return naziv;
    }

    public void setNaziv(String naziv) {
        this.naziv = naziv;
    }

    public ArrayList<Pitanje> getPitanja() {
        return pitanja;
    }

    public void setPitanja(ArrayList<Pitanje> pitanja) {
        this.pitanja = pitanja;
    }

    public Kategorija getKategorija() {
        return kategorija;
    }

    public void setKategorija(Kategorija kategorija) {
        this.kategorija = kategorija;
    }

    public void dodajNovoPitanje(Pitanje pitanje) {
        if(pitanja == null) pitanja = new ArrayList<>();
        pitanja.add(pitanje);
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        Kviz kviz = (Kviz) o;

        return getNaziv() != null ? getNaziv().equals(kviz.getNaziv()) : kviz.getNaziv() == null;
    }

    @Override
    public int hashCode() {
        return getNaziv() != null ? getNaziv().hashCode() : 0;
    }

    @Override
    public String toString() {
        return "Kviz{" +
                "naziv='" + naziv + '\'' +
                ", pitanja=" + pitanja +
                ", kategorija=" + kategorija +
                '}';
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(naziv);
        dest.writeTypedList(pitanja);
        dest.writeParcelable(kategorija, flags);
    }
}
