package ba.unsa.etf.rma.Aktivnosti;

import android.content.Intent;
import android.graphics.Color;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.api.client.googleapis.auth.oauth2.GoogleCredential;
import com.google.common.collect.Lists;
import com.maltaisn.icondialog.Icon;
import com.maltaisn.icondialog.IconDialog;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;

import ba.unsa.etf.rma.Klase.Kategorija;
import ba.unsa.etf.rma.R;

public class DodajKategorijuAkt extends AppCompatActivity implements IconDialog.Callback {

    EditText etNaziv;
    EditText etIkona;
    Button btnDodajIkonu;
    Button btnDodajKategoriju;
    Kategorija k;
    private Icon[] selectedIcons;
    IconDialog iconDialog = new IconDialog();

    public class UpdateBaze extends AsyncTask<String, Void, Void> {
        @Override
        protected Void doInBackground(String... strings) {
            try {
                InputStream is = getResources().openRawResource(R.raw.secret);
                GoogleCredential credentials = GoogleCredential.fromStream(is).createScoped(Lists.newArrayList("https://www.googleapis.com/auth/datastore"));
                credentials.refreshToken();
                String TOKEN = credentials.getAccessToken();
                String surl = "https://firestore.googleapis.com/v1/projects/spirala3-49671/databases/(default)/documents/Kategorije?access_token=" + TOKEN;
                URL url = new URL(surl);
                HttpURLConnection connection = (HttpURLConnection) url.openConnection();
                connection.setRequestMethod("POST");
                connection.setRequestProperty("Content-Type", "application/json");
                connection.setRequestProperty("Accept", "application/json");
                connection.setDoOutput(true);
                String JsonOutput = "{\"fields\" : { \n \"naziv\": { \n \"stringValue\": \" " + k.getNaziv() + "\" \n }, \n \"idIkonice\": {" +
                        "\n \"stringValue\": \"" + k.getId() +"\" \n } \n } \n }";

                try(OutputStream os = connection.getOutputStream()) {
                    byte[] input = JsonOutput.getBytes("utf-8");
                    os.write(input, 0, input.length);
                }
                try(BufferedReader br = new BufferedReader(
                        new InputStreamReader(connection.getInputStream(), "utf-8"))) {
                    StringBuilder response = new StringBuilder();
                    String responseLine = null;
                    while ((responseLine = br.readLine()) != null) {
                        response.append(responseLine.trim());
                    }
                    Log.d("HELLO", response.toString());
                }


            } catch(Exception e) {
                e.printStackTrace();
            }

            return null;
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dodaj_kategoriju_akt);

        etNaziv = findViewById(R.id.etNaziv);
        etIkona = findViewById(R.id.etIkona);
        etIkona.setFocusable(false);
        etIkona.setEnabled(false);

        btnDodajIkonu = findViewById(R.id.btnDodajIkonu);
        btnDodajKategoriju = findViewById(R.id.btnDodajKategoriju);


        btnDodajIkonu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                iconDialog.setSelectedIcons(selectedIcons);
                iconDialog.show(getSupportFragmentManager(), "icon_dialog");
            }
        });

        btnDodajKategoriju.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(etNaziv.getText().toString().equalsIgnoreCase(""))
                    etNaziv.setBackgroundColor(Color.RED);
                else if(etIkona.getText().toString().equalsIgnoreCase("")) {
                    etNaziv.setBackgroundColor(Color.TRANSPARENT);
                    Toast.makeText(DodajKategorijuAkt.this, "Odaberite ikonu", Toast.LENGTH_SHORT).show();
                }
                else {
                    Intent intent = getIntent();
                    k = new Kategorija(etNaziv.getText().toString(), etIkona.getText().toString());
                    new UpdateBaze().execute();
                    intent.putExtra("kategorija", k);
                    setResult(3, intent);
                    finish();
                }
            }
        });
    }

    @Override
    public void onBackPressed() {
        Intent intent = getIntent();
        intent.putExtra("kategorija", new Kategorija("", ""));
        setResult(3, intent);
        finish();
    }

    @Override
    public void onIconDialogIconsSelected(Icon[] icons) {
        selectedIcons = icons;
        etIkona.setText(String.valueOf(icons[0].getId()));
    }

}
