package ba.unsa.etf.rma.Aktivnosti;


import android.support.v4.app.FragmentManager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.FrameLayout;

import ba.unsa.etf.rma.fragmenti.InformacijeFrag;
import ba.unsa.etf.rma.Klase.Kviz;
import ba.unsa.etf.rma.fragmenti.PitanjeFrag;
import ba.unsa.etf.rma.R;

public class IgrajKvizAkt extends AppCompatActivity implements PitanjeFrag.zavrsiloPitanje {
    PitanjeFrag pitFrag;
    InformacijeFrag infFrag;
    Kviz kviz;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_igraj_kviz_akt);

        kviz = getIntent().getParcelableExtra("kviz");

        FragmentManager fm = getSupportFragmentManager();
        FrameLayout informacije = findViewById(R.id.informacijePlace);
        FrameLayout pitanja = findViewById(R.id.pitanjePlace);

        infFrag = (InformacijeFrag) fm.findFragmentById(R.id.informacijePlace);
        pitFrag = (PitanjeFrag) fm.findFragmentById(R.id.pitanjePlace);

        if(infFrag==null) {
            infFrag = new InformacijeFrag();

            Bundle args =new Bundle();
            args.putParcelable("kviz", kviz);
            infFrag.setArguments(args);

            fm.beginTransaction().replace(R.id.informacijePlace, infFrag).commit();
        } else {
            fm.popBackStack(null, FragmentManager.POP_BACK_STACK_INCLUSIVE);
        }
        if(pitFrag==null) {
            pitFrag = new PitanjeFrag();

            Bundle args =new Bundle();
            args.putParcelable("kviz", kviz);
            pitFrag.setArguments(args);
            fm.beginTransaction().replace(R.id.pitanjePlace, pitFrag).commit();

        } else {
            fm.popBackStack(null, FragmentManager.POP_BACK_STACK_INCLUSIVE);
        }
    }


    @Override
    public void zavrsiloPitanje(boolean tacan, int i, int tacni) {
        Bundle args = new Bundle();
        if(tacan) {
            args.putInt("tacan", 1);
        } else {
            args.putInt("tacan", 0);
        }
        args.putInt("brojTacnih", tacni);
        args.putInt("i", i);
        infFrag.setArguments(args);
        getSupportFragmentManager().beginTransaction().detach(infFrag).attach(infFrag).commit();
    }

    @Override
    public void onBackPressed() {
        PitanjeFrag.brojTacnih=0;
        PitanjeFrag.i=0;
        super.onBackPressed();
    }
}
