package ba.unsa.etf.rma.Aktivnosti;

import android.app.Service;
import android.content.Intent;
import android.content.res.Configuration;
import android.os.AsyncTask;
import android.os.IBinder;
import android.support.v4.app.FragmentManager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.FrameLayout;
import android.widget.ListView;
import android.widget.Spinner;

import com.google.api.client.googleapis.auth.oauth2.GoogleCredential;
import com.google.common.collect.Lists;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;

import ba.unsa.etf.rma.Klase.Kategorija;
import ba.unsa.etf.rma.Klase.Kviz;
import ba.unsa.etf.rma.Klase.MyArrayAdapterKviz;
import ba.unsa.etf.rma.Klase.Pitanje;
import ba.unsa.etf.rma.Klase.SpinnerAdapter;
import ba.unsa.etf.rma.R;
import ba.unsa.etf.rma.fragmenti.DetailFrag;
import ba.unsa.etf.rma.fragmenti.ListaFrag;

public class KvizoviAkt extends AppCompatActivity implements ListaFrag.filtrirajKvizove {
    ArrayList<Kategorija> kategorije = new ArrayList<>();
    ArrayList<Kviz> kvizovi = new ArrayList<>();
    ArrayList<Pitanje> pitanja = new ArrayList<>();
    MyArrayAdapterKviz adapter;
    ListView lvKvizovi;
    SpinnerAdapter spinnerAdapter;
    Spinner spinner;
    ListaFrag listafrag;
    DetailFrag detailFrag;
    Configuration config;

 public class UpdateBaze extends AsyncTask<String, Void, Void> {

     @Override
     protected Void doInBackground(String... strings) {

         try {
             InputStream is = getResources().openRawResource(R.raw.secret);
             GoogleCredential credentials = GoogleCredential.fromStream(is).createScoped(Lists.newArrayList("https://www.googleapis.com/auth/datastore"));
             credentials.refreshToken();
             String TOKEN = credentials.getAccessToken();
                 //Kategorije
                 String sUrl = "https://firestore.googleapis.com/v1/projects/spirala3-49671/databases/(default)/documents/Kategorije?access_token=";
                 sUrl += TOKEN;
                 Log.d("TOKEN", TOKEN);
                 URL url = new URL(sUrl);
                 HttpURLConnection connection = (HttpURLConnection) url.openConnection();
                 connection.setRequestMethod("GET");
                 connection.setRequestProperty("Content-Type", "application/json");
                 connection.setRequestProperty("Accept", "application/json");
                 InputStream in = new BufferedInputStream(connection.getInputStream());
                 String rezultat = convertStreamToString(in);
                 JSONObject jo = new JSONObject(rezultat);
                 JSONArray documents = jo.getJSONArray("documents");
                 JSONObject jo2;
                 for (int i = 0; i < documents.length(); i++) {
                     jo = documents.getJSONObject(i);
                     jo = jo.getJSONObject("fields");
                     jo2 = jo.getJSONObject("idIkonice");
                     String idIkonice = jo2.getString("stringValue");
                     jo2 = jo.getJSONObject("naziv");
                     String naziv = jo2.getString("stringValue");
                     Kategorija k = new Kategorija(naziv, idIkonice);
                     kategorije.add(k);
                 }

                 //Pitanja
                 sUrl = "https://firestore.googleapis.com/v1/projects/spirala3-49671/databases/(default)/documents/Pitanja?access_token=";
                 sUrl += TOKEN;
                 url = new URL(sUrl);
                 connection = (HttpURLConnection) url.openConnection();
                 connection.setRequestMethod("GET");
                 connection.setRequestProperty("Content-Type", "application/json");
                 connection.setRequestProperty("Accept", "application/json");
                 in = new BufferedInputStream(connection.getInputStream());
                 rezultat = convertStreamToString(in);
                 jo = new JSONObject(rezultat);
                 documents = jo.getJSONArray("documents");
                 for (int i = 0; i < documents.length(); i++) {
                     jo = documents.getJSONObject(i);
                     jo = jo.getJSONObject("fields");
                     jo2 = jo.getJSONObject("indeksTacnog");
                     String tacan = jo2.getString("stringValue");
                     jo2 = jo.getJSONObject("naziv");
                     String naziv = jo2.getString("stringValue");
                     jo2 = jo.getJSONObject("odgovori");
                     jo = jo2.getJSONObject("arrayValue");
                     JSONArray odg = jo.getJSONArray("values");
                     ArrayList<String> odgovori = new ArrayList<>();
                     String x;
                     for (int j = 0; j < odg.length(); j++) {
                         x = odg.getJSONObject(j).getString("stringValue");
                         odgovori.add(x);
                     }
                     pitanja.add(new Pitanje(naziv, naziv, odgovori, odgovori.get(Integer.parseInt(tacan))));
                 }

                 //Kvizovi
                 sUrl = "https://firestore.googleapis.com/v1/projects/spirala3-49671/databases/(default)/documents/Kvizovi?access_token=";
                 sUrl += TOKEN;
                 url = new URL(sUrl);
                 connection = (HttpURLConnection) url.openConnection();
                 connection.setRequestMethod("GET");
                 connection.setRequestProperty("Content-Type", "application/json");
                 connection.setRequestProperty("Accept", "application/json");
                 in = new BufferedInputStream(connection.getInputStream());
                 rezultat = convertStreamToString(in);
                 jo = new JSONObject(rezultat);
                 documents = jo.getJSONArray("documents");
                 JSONArray pitanjaJSON;
                 JSONArray categories;
                 for (int i = 0; i < documents.length(); i++) {
                     jo = documents.getJSONObject(i);
                     jo = jo.getJSONObject("fields");
                     jo2 = jo.getJSONObject("naziv");
                     String naziv = jo2.getString("stringValue");
                     jo2 = jo.getJSONObject("idKategorije");
                     jo2 = jo2.getJSONObject("arrayValue");
                     categories = jo2.getJSONArray("values");
                     String katnaz = categories.getJSONObject(0).getString("stringValue");
                     String katid = categories.getJSONObject(1).getString("stringValue");
                     Kviz k = new Kviz(naziv, new Kategorija(katnaz, katid));

                     jo2 = jo.getJSONObject("pitanja");
                     jo2 = jo2.getJSONObject("arrayValue");
                     pitanjaJSON = jo2.getJSONArray("values");
                     String x;
                     ArrayList<Pitanje> pomocnapitanja = new ArrayList<>();
                     for (int j = 0; j < pitanjaJSON.length(); j++) {
                         x = pitanjaJSON.getJSONObject(j).getString("stringValue");
                         for(int s=0; s<pitanja.size(); s++) {
                             if(pitanja.get(s).getNaziv().equalsIgnoreCase(x)) pomocnapitanja.add(pitanja.get(s));
                         }
                     }
                     k.setPitanja(pomocnapitanja);
                     kvizovi.add(kvizovi.size()-1, k);
                 }
         } catch (Exception e) {
             e.printStackTrace();
         }
         return null;
     }

 }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.kvizovi_akt);

        new UpdateBaze().execute();

        config = getResources().getConfiguration();
        if(config.screenWidthDp < 500) {

            spinner = findViewById(R.id.spPostojeceKategorije);
            lvKvizovi = findViewById(R.id.lvKvizovi);

            kategorije.add(new Kategorija("Svi", "337"));

            final Kviz kviz = new Kviz("Dodaj kviz", new Kategorija("kategorija", "337"));
            kviz.dodajPitanje(new Pitanje("Testno pitanje", "tekst", new ArrayList<String>(), "tacan"));
            kvizovi.add(kviz);

            spinnerAdapter = new SpinnerAdapter(this, kategorije);
            spinner.setAdapter(spinnerAdapter);

            adapter = new MyArrayAdapterKviz(this, kvizovi);
            lvKvizovi.setAdapter(adapter);

            lvKvizovi.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                @Override
                public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                    if (kvizovi.get(position).getNaziv().equalsIgnoreCase("Dodaj kviz")) return;
                    Intent intent = new Intent(KvizoviAkt.this, IgrajKvizAkt.class);
                    intent.putExtra("kviz", kvizovi.get(position));
                    startActivity(intent);
                }

            });
            lvKvizovi.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
                @Override
                public boolean onItemLongClick(AdapterView<?> parent, View view, int position, long id) {
                    Intent intent = new Intent(KvizoviAkt.this, DodajKvizAkt.class);
                    intent.putExtra("kviz", kvizovi.get(position));
                    intent.putExtra("kategorije", kategorije);
                    intent.putExtra("pitanja", pitanja);
                    startActivityForResult(intent, 2);
                    return true;
                }
            });

            spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {

                public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                    if (!kategorije.get(position).getNaziv().equalsIgnoreCase("Svi")) {
                        adapter = new MyArrayAdapterKviz(KvizoviAkt.this, kvizovi);
                        lvKvizovi.setAdapter(adapter);
                        adapter.getFilter().filter(kategorije.get(position).getNaziv());
                        //DOHVATITI KVIZOVE SA KATEGORIJOM
                    } else {
                        adapter = new MyArrayAdapterKviz(KvizoviAkt.this, kvizovi);
                        lvKvizovi.setAdapter(adapter);
                    }
                }

                public void onNothingSelected(AdapterView<?> parent) {
                }

            });
        }

        else {
            kategorije.add(new Kategorija("Svi", "337"));
            Kviz kviz = new Kviz("Dodaj kviz", new Kategorija("kategorija", "337"));
            kviz.dodajPitanje(new Pitanje("Testno pitanje", "tekst", new ArrayList<String>(), "tacan"));
            kvizovi.add(kviz);

            FragmentManager fm = getSupportFragmentManager();
            FrameLayout listPlace = findViewById(R.id.listPlace);
            FrameLayout detailPlace = findViewById(R.id.detailPlace);
            listafrag = (ListaFrag) fm.findFragmentById(R.id.listPlace);
            detailFrag = (DetailFrag) fm.findFragmentById(R.id.detailPlace);

            if(listafrag == null) {
                listafrag = new ListaFrag();
                Bundle args = new Bundle();
                args.putParcelableArrayList("kategorije", kategorije);
                args.putParcelableArrayList("kvizovi", kvizovi);
                listafrag.setArguments(args);
                fm.beginTransaction().replace(R.id.listPlace, listafrag).commit();
            } else {
                fm.popBackStack(null, FragmentManager.POP_BACK_STACK_INCLUSIVE);
            }
            if(detailFrag == null) {
                detailFrag = new DetailFrag();
                Bundle args = new Bundle();
                args.putParcelableArrayList("kvizovi", kvizovi);
                args.putParcelableArrayList("kategorije", kategorije);
                detailFrag.setArguments(args);
                fm.beginTransaction().replace(R.id.detailPlace, detailFrag).commit();
            } else {
                fm.popBackStack(null, FragmentManager.POP_BACK_STACK_INCLUSIVE);
            }
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if(requestCode == 2) {
            Kviz k = data.getParcelableExtra("kviz");
            if (!k.getNaziv().equalsIgnoreCase("")) {
                int i = 0;
                while (i < kvizovi.size()) {
                    if (kvizovi.get(i).getNaziv().equalsIgnoreCase(k.getNaziv()))
                        kvizovi.remove(i);
                    i++;
                }
                kategorije.add(k.getKategorija());
                if(k.getKategorija().getNaziv().equalsIgnoreCase("kategorija"))
                    kategorije.remove(kategorije.size()-1);
                i=0;
                while (i < kategorije.size()-1) {
                    if (kategorije.get(i).getNaziv().equalsIgnoreCase(k.getKategorija().getNaziv()))
                        kategorije.remove(kategorije.size()-1);
                    i++;
                }
                kvizovi.add(kvizovi.size() - 1, k);
                adapter = new MyArrayAdapterKviz(KvizoviAkt.this, kvizovi);
                lvKvizovi.setAdapter(adapter);
                spinner.setSelection(0);

            }
        }
        else {
            super.onActivityResult(requestCode, resultCode, data);
            listafrag.updateListu();
        }
    }

    @Override
    public void filtrirajKvizove(ArrayList<Kviz> kvizovi1, String kategorija, ArrayList<Kategorija> kats) {
        Bundle args = new Bundle();
        if(kategorija.equalsIgnoreCase("Svi")) {
            args.putParcelableArrayList("kvizovi", kvizovi);
            args.putParcelableArrayList("kategorije", kategorije);
        } else {
            args.putString("filterKategorija", kategorija);
            args.putParcelableArrayList("kvizovi", kvizovi1);
            args.putParcelableArrayList("kategorije", kats);
        }
      detailFrag.setArguments(args);
      getSupportFragmentManager().beginTransaction().detach(detailFrag).attach(detailFrag).commit();
    }

    public static String convertStreamToString(InputStream is) {
        BufferedReader reader = new BufferedReader(new InputStreamReader(is));
        StringBuilder sb = new StringBuilder();
        String line = null;
        try {
            while ((line = reader.readLine()) != null) {
                sb.append(line + "\n");
            }
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            try {
                is.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        return sb.toString();
    }


}
