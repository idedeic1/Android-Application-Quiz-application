package ba.unsa.etf.rma.Klase;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Filter;
import android.widget.Filterable;
import android.widget.ImageView;
import android.widget.TextView;

import com.maltaisn.icondialog.Icon;
import com.maltaisn.icondialog.IconHelper;
import com.maltaisn.icondialog.IconView;

import java.util.ArrayList;

import ba.unsa.etf.rma.R;

public class MyArrayAdapterKviz extends BaseAdapter implements Filterable {
    ArrayList<Kviz> kvizovi;
    Context context;
    public MyArrayAdapterKviz(Context context, ArrayList<Kviz> arrayList) {
        this.kvizovi =arrayList;
        this.context=context;
    }
    @Override
    public int getCount() {
        return kvizovi.size();
    }

    @Override
    public Object getItem(int position) {
        return null;
    }

    @Override
    public long getItemId(int position) {
        return 0;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {

        Kviz kviz = kvizovi.get(position);
        if (convertView == null) {
            LayoutInflater layoutInflater = LayoutInflater.from(context);
            convertView=layoutInflater.inflate(R.layout.kvizovi_list_view_item, null);


        }
        IconView slika = convertView.findViewById(R.id.slika);
        try {
            slika.setIcon(Integer.parseInt(kviz.getKategorija().getId()));
        } catch (Exception e) {
            slika.setIcon(337);
        }

        TextView imeKviza = convertView.findViewById(R.id.naziv);
        imeKviza.setText(kviz.getNaziv());

        return convertView;
    }
    @Override
    public Filter getFilter() {

        Filter filter = new Filter() {

            @SuppressWarnings("unchecked")
            @Override
            protected void publishResults(CharSequence constraint, FilterResults results) {

                kvizovi = (ArrayList<Kviz>) results.values;
                notifyDataSetChanged();
            }

            @Override
            public FilterResults performFiltering(CharSequence constraint) {
                ArrayList<Kviz> pomocna = kvizovi;

                FilterResults results = new FilterResults();
                ArrayList<Kviz> FilteredArray = new ArrayList<>();

                for(Kviz j: pomocna){
                    if(j.getKategorija().getNaziv().equalsIgnoreCase((String) constraint))
                        FilteredArray.add(j);
                }

                Kviz kviz = new Kviz("Dodaj kviz", new Kategorija("kategorija", "337"));
                FilteredArray.add(kviz);

                results.count = FilteredArray.size();
                results.values = FilteredArray;

                return results;
            }
        };
        return filter;
    }
}
