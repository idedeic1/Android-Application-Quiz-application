package ba.unsa.etf.rma.Klase;

import android.content.Context;
import android.database.DataSetObserver;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ListAdapter;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

import ba.unsa.etf.rma.R;

public class MyArrayAdapterPitanja extends BaseAdapter {
    ArrayList<Pitanje> arrayList;
    Context context;
    public MyArrayAdapterPitanja(Context context, ArrayList<Pitanje> arrayList) {
        this.arrayList=arrayList;
        this.context=context;
    }
    @Override
    public int getCount() {
        return arrayList.size();
    }
    @Override
    public Object getItem(int position) {
        return null;
    }

    @Override
    public long getItemId(int position) {
        return 0;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {

        Pitanje pitanje = arrayList.get(position);
        if (convertView == null) {
            LayoutInflater layoutInflater = LayoutInflater.from(context);
            convertView=layoutInflater.inflate(R.layout.text_view_item, null);


        }
        TextView nazivPitanja = convertView.findViewById(R.id.naziv);
        nazivPitanja.setText(pitanje.getNaziv());

        return convertView;
    }

}