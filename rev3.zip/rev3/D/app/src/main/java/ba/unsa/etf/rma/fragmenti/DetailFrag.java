package ba.unsa.etf.rma.fragmenti;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.GridView;
import android.widget.Toast;

import java.util.ArrayList;

import ba.unsa.etf.rma.Aktivnosti.DodajKvizAkt;
import ba.unsa.etf.rma.Aktivnosti.IgrajKvizAkt;
import ba.unsa.etf.rma.Aktivnosti.KvizoviAkt;
import ba.unsa.etf.rma.Klase.Kategorija;
import ba.unsa.etf.rma.Klase.Kviz;
import ba.unsa.etf.rma.Klase.MyArrayAdapterKvizGridView;
import ba.unsa.etf.rma.R;

public class DetailFrag extends Fragment {
    ArrayList<Kviz> kvizovi;
    ArrayList<Kategorija> kategorije;
    MyArrayAdapterKvizGridView adapter;
    GridView gridView;
    String filterKategorija;

    @Override
    public View onCreateView (LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState ) {
        return inflater.inflate(R.layout.detail_frag, container, false);
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);

        try{
            kvizovi = getArguments().getParcelableArrayList("kvizovi");
            kategorije = getArguments().getParcelableArrayList("kategorije");

            gridView = getView().findViewById(R.id.gridKvizovi);

            adapter = new MyArrayAdapterKvizGridView(getActivity(), kvizovi);
            gridView.setAdapter(adapter);
            if(getArguments().containsKey("filterKategorija")) {
                filterKategorija = getArguments().getString("filterKategorija");
                adapter.getFilter().filter(filterKategorija);
            }

            gridView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                @Override
                public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                    if (kvizovi.get(position).getNaziv().equalsIgnoreCase("Dodaj kviz")) return;
                    Intent intent = new Intent(getActivity(), IgrajKvizAkt.class);
                    intent.putExtra("kviz", kvizovi.get(position));
                    startActivity(intent);
                }
            });
            gridView.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
                @Override
                public boolean onItemLongClick(AdapterView<?> parent, View view, int position, long id) {
                    Intent intent = new Intent(getActivity(), DodajKvizAkt.class);
                    intent.putExtra("kviz", kvizovi.get(position));
                    intent.putExtra("kategorije", kategorije);
                    startActivityForResult(intent, 5);
                    return true;
                }
            });

        } catch(Exception e) {
            Toast.makeText(getContext(), "Nije uspjelo.", Toast.LENGTH_SHORT).show();
        }

    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(requestCode==5) {
            Kviz k = data.getParcelableExtra("kviz");
            if (!k.getNaziv().equalsIgnoreCase("")) {
                int i = 0;
                while (i < kvizovi.size()) {
                    if (kvizovi.get(i).getNaziv().equalsIgnoreCase(k.getNaziv()))
                        kvizovi.remove(i);
                    i++;
                }
                kategorije.add(k.getKategorija());
                if(k.getKategorija().getNaziv().equalsIgnoreCase("kategorija"))
                    kategorije.remove(kategorije.size()-1);
                i = 0;
                while (i < kategorije.size() - 1) {
                    if (kategorije.get(i).getNaziv().equalsIgnoreCase(k.getKategorija().getNaziv()))
                        kategorije.remove(kategorije.size() - 1);
                    i++;
                }
                kvizovi.add(kvizovi.size() - 1, k);
                adapter = new MyArrayAdapterKvizGridView(getContext(), kvizovi);
                gridView.setAdapter(adapter);
            }

        }
    }
}
