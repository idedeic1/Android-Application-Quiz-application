package ba.unsa.etf.rma.fragmenti;

import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentTransaction;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import ba.unsa.etf.rma.Klase.Kviz;
import ba.unsa.etf.rma.R;

public class PitanjeFrag extends Fragment {
    public static int i=0;
    ListView odgovori;
    Kviz kviz;
    TextView nazivPitanja;
    private zavrsiloPitanje zavrsiloPitanje;
    public static int brojTacnih = 0;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        return inflater.inflate(R.layout.pitanje_frag, container, false);
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);

        try {
            nazivPitanja = getView().findViewById(R.id.tekstPitanja);
            odgovori = getView().findViewById(R.id.odgovoriPitanja);

            if (getArguments().containsKey("kviz")) {
                kviz = getArguments().getParcelable("kviz");

                if(kviz.getPitanja().get(i).getNaziv().equalsIgnoreCase("Dodaj pitanje")) {
                    String str = "Kviz je zavrsen!";
                    nazivPitanja.setText(str);
                }else nazivPitanja.setText(kviz.getPitanja().get(i).getNaziv());

                ArrayAdapter<String> adapter = new ArrayAdapter<>(getActivity(), R.layout.text_view_item, R.id.naziv, kviz.getPitanja().get(i).dajRandomOdgovore());
                odgovori.setAdapter(adapter);

                try {
                    zavrsiloPitanje = (zavrsiloPitanje) getActivity ();
                } catch ( ClassCastException e ) {
                    throw new ClassCastException(getActivity().toString()+ "Treba implementirati zavrsiloPitanje" );
                }
            }
        } catch(Exception e) {
            Toast.makeText(getContext(), "Nije uspjelo", Toast.LENGTH_SHORT).show();
        }
        odgovori.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                try {
                    if (kviz.getPitanja().get(i).getOdgovori().get(position).equalsIgnoreCase(kviz.getPitanja().get(i).getTacan())) {
                        brojTacnih++;
                        i++;
                        for (int j = 0; j < odgovori.getChildCount(); j++) {
                            if(position == j ){
                                odgovori.getChildAt(j).setBackgroundColor(Color.parseColor("#7FFF00"));
                            }else{
                                odgovori.getChildAt(j).setBackgroundColor(Color.TRANSPARENT);
                            }
                        }
                        final Handler handler = new Handler();
                        handler.postDelayed(new Runnable() {
                            @Override
                            public void run() {
                                try {
                                    FragmentTransaction ft = getFragmentManager().beginTransaction();
                                    ft.detach(PitanjeFrag.this);
                                    ft.attach(PitanjeFrag.this);
                                    ft.commit();
                                } catch (Exception e) {}
                            }
                        }, 2000);
                        zavrsiloPitanje.zavrsiloPitanje(true, i, brojTacnih);
                    } else {
                        i++;
                        for (int j = 0; j < odgovori.getChildCount(); j++) {
                            if(odgovori.getItemAtPosition(j).toString().equalsIgnoreCase(kviz.getPitanja().get(i-1).getTacan())) {
                                odgovori.getChildAt(j).setBackgroundColor(Color.parseColor("#7FFF00"));
                            }
                            else if(position == j ){
                                odgovori.getChildAt(j).setBackgroundColor(Color.parseColor("#FF3030"));
                            }else{
                                odgovori.getChildAt(j).setBackgroundColor(Color.TRANSPARENT);
                            }
                        }
                        final Handler handler = new Handler();
                        handler.postDelayed(new Runnable() {
                            @Override
                            public void run() {
                                try {
                                    FragmentTransaction ft = getFragmentManager().beginTransaction();
                                    ft.detach(PitanjeFrag.this);
                                    ft.attach(PitanjeFrag.this);
                                    ft.commit();
                                } catch (Exception e) {}
                            }
                        }, 2000);
                        zavrsiloPitanje.zavrsiloPitanje(false, i, brojTacnih);
                    }
                }catch(Exception e) {
                    Toast.makeText(getActivity(), "Doslo je do greske.", Toast.LENGTH_SHORT).show();
                }

            }
        });
    }


    public interface zavrsiloPitanje {
        public void zavrsiloPitanje (boolean tacan, int i, int tacni);
    }



}
