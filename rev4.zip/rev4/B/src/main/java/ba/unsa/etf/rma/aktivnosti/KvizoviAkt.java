package ba.unsa.etf.rma.aktivnosti;

import android.Manifest;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.Toast;

import com.google.api.client.googleapis.auth.oauth2.GoogleCredential;
import com.google.common.collect.Lists;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.concurrent.ExecutionException;

import ba.unsa.etf.rma.R;
import ba.unsa.etf.rma.adapteri.AdapterZaListuKvizova;
import ba.unsa.etf.rma.adapteri.AdapterZaSpinner;
import ba.unsa.etf.rma.klase.Kategorija;
import ba.unsa.etf.rma.klase.Kviz;
import ba.unsa.etf.rma.klase.Pitanje;

import static ba.unsa.etf.rma.aktivnosti.DodajKvizAkt.convertStreamToString;
import static android.content.pm.PackageManager.PERMISSION_GRANTED;


public class KvizoviAkt extends AppCompatActivity {

    Spinner spinner;
    ListView listaKvizova;
    ArrayList<Kategorija> kategorije = new ArrayList<>();
    ArrayList<Kviz> kvizovi = new ArrayList<>();
    ArrayList<Pitanje> pitanjaBaza = new ArrayList<>();
    AdapterZaSpinner adapterZaSpinner;
    AdapterZaListuKvizova adapterZaListuKvizova;
    private static final int READ_REQUEST_CODE = 42;
    String TOKEN = "";
    Kategorija kategorija;
    private static final int PERMISSION_REQUEST_CODE = 1;
    private boolean perm = true;
    private Long vrijemeDoEventaSekunde;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.aktivnost_kvizovi);
        new DajToken().execute("dajToken");
        napuniKomplikovanije();
        checkPermissions(PERMISSION_REQUEST_CODE, Manifest.permission.READ_CALENDAR, Manifest.permission.WRITE_CALENDAR);

        listaKvizova = (ListView) findViewById(R.id.lvKvizovi);
        spinner = (Spinner) findViewById(R.id.spPostojeceKategorije);
        adapterZaSpinner = new AdapterZaSpinner(this, kategorije);
        spinner.setAdapter(adapterZaSpinner);
        new DobaviSveKategorije().execute("Kategorije");
        new DobaviSvaPitanja().execute("Pitanja");



        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {

                kategorija = (Kategorija) parent.getItemAtPosition(position);

                if (kategorija.getId().equals("svi")) {
                    new DobaviSveKvizove().execute("Kvizovi");
                } else {
                    new DobaviSveKvizovePoKategoriji().execute("Kvizovi");
                }
            }


            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        listaKvizova.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> parent, View view, int position, long id) {
                Intent dodajKviz = new Intent(getApplicationContext(), DodajKvizAkt.class);
                Kviz kviz = (Kviz) parent.getItemAtPosition(position);

                int zaistaPritisnutaPozicija = position;
                for (int i = 0; i < kvizovi.size(); i++) {
                    if (kvizovi.get(i).getNaziv().equalsIgnoreCase(kviz.getNaziv())) {
                        zaistaPritisnutaPozicija = i;
                    }
                }

                dodajKviz.putExtra("idKviza", kviz.getId());
                dodajKviz.putParcelableArrayListExtra("kategorije", kategorije);
                dodajKviz.putParcelableArrayListExtra("listaKvizovi", kvizovi);
                dodajKviz.putExtra("pritisnutiKviz", kviz);
                dodajKviz.putParcelableArrayListExtra("pitanja", kviz.getPitanja());
                dodajKviz.putExtra("pozicijaKliknutogKviza", zaistaPritisnutaPozicija);
                startActivityForResult(dodajKviz, 1);

                return true;
            }
        });

        listaKvizova.setOnItemClickListener(new AdapterView.OnItemClickListener() {

            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Intent intent = new Intent(getApplicationContext(), IgrajKvizAkt.class);
                Kviz kviz = (Kviz) parent.getItemAtPosition(position);

                for(Pitanje p : kviz.getPitanja()){
                    if(p.getNaziv().equalsIgnoreCase("Dodaj pitanje")){
                        kviz.getPitanja().remove(p);
                        break;
                    }
                }

                if (!(position == kvizovi.size() - 1)) {
                    if (kviz.getPitanja().size() != 0 && daLiIMaEventPrijeVremena((int) ((kviz.getPitanja().size() / 2.) * 60)) && perm) {
                        AlertDialog alertDialog = new AlertDialog.Builder(KvizoviAkt.this).create();
                        alertDialog.setTitle("Alert");


                            alertDialog.setMessage("Imate događaj u kalendaru za " + vrijemeDoEventaSekunde + " sekundi!");


                        alertDialog.setButton(AlertDialog.BUTTON_NEUTRAL, "OK",
                                new DialogInterface.OnClickListener() {
                                    public void onClick(DialogInterface dialog, int which) {
                                        dialog.dismiss();
                                    }
                                });
                        alertDialog.show();
                    } else if (perm) {
                        intent.putExtra("kviz", kvizovi.get(position));
                        intent.putParcelableArrayListExtra("pitanja", kviz.getPitanja());
                        startActivity(intent);
                    }
                }
            }
        });
    }

    private void napuniKomplikovanije() {

        Kategorija svi = new Kategorija("Svi", "svi");
        kategorije.add(svi);

        //Kviz kviz = new Kviz("Kosarka", null, svi);
        //kvizovi.add(kviz);

        Kviz dodaj = new Kviz("Dodaj kviz", null, null);
        kvizovi.add(dodaj);

    }

    private void itemPLUS(){
        Kviz dodaj = new Kviz("Dodaj kviz", null, null);
        kvizovi.add(kvizovi.size(), dodaj);
    }

    private boolean checkPermissions(int callbackId, String... permissionsId) {
        boolean permissions = true;
        for (String p : permissionsId) {
            permissions = permissions && ContextCompat.checkSelfPermission(this, p) == PERMISSION_GRANTED;
        }

        if (!permissions)
            ActivityCompat.requestPermissions(this, permissionsId, callbackId);
        return permissions;
    }

    private boolean daLiIMaEventPrijeVremena(int vrijemeUSekundama) {
        if (perm) {
            Cursor cursor = getContentResolver().query(
                    Uri.parse("content://com.android.calendar/events"), new String[]{"title", "dtstart", "dtend"}, "deleted != 1", null, null);
            cursor.moveToFirst();
            String CNames[] = new String[cursor.getCount()];

            long trenutnoVrijeme = System.currentTimeMillis();

            long trenutnoPlusBrojPitanja = trenutnoVrijeme + vrijemeUSekundama * 1000;

            ArrayList<String> pomoc = new ArrayList<>();
            pomoc.add(cursor.getString(1));
            if(cursor.getString(2) == null){
                pomoc.add(cursor.getString(0));
            } else {
                pomoc.add(cursor.getString(2));
            }

            for (int i = 0; i < CNames.length; i++) {
                Long datumPocetka = Long.parseLong(cursor.getString(1));
                //Long datumKraja = Long.parseLong(cursor.getString(2));
                /*if(datumPocetka < trenutnoVrijeme && datumKraja > trenutnoVrijeme) {
                    vrijemeDoZavrsetkaEventaKojiTraje = ( datumKraja - trenutnoVrijeme )/ 60000.;
                    vrijemeDoEventa = 0;
                    return true;
                } else*/ if (datumPocetka > trenutnoVrijeme && datumPocetka < trenutnoPlusBrojPitanja) {
                    vrijemeDoEventaSekunde = (datumPocetka - trenutnoVrijeme) / 1000;
                    return true;
                }
                CNames[i] = cursor.getString(0);
                cursor.moveToNext();

            }
        }
        return false;
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        if(requestCode == PERMISSION_REQUEST_CODE) {
            if(grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                perm = true;
            } else {
                perm = false;
            }
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);


        if (requestCode == 1) {
            if (resultCode == RESULT_OK) {

                if (data.getParcelableExtra("noviKviz") == null) {
                    ArrayList<Kategorija> kat = data.<Kategorija>getParcelableArrayListExtra("azuriraneKategorije");
                    kategorije.clear();
                    kategorije.addAll(kat);
                    adapterZaSpinner.notifyDataSetChanged();
                } else {

                    int pozicijaKliknutogKviza = data.getIntExtra("pozicijaKliknutogKviza", -1);
                    Kviz noviKviz = (Kviz) data.getParcelableExtra("noviKviz");
                    noviKviz.setId((String) data.getStringExtra("idKviza"));
                    boolean postojiLi = false;
                    ArrayList<Kategorija> kat = data.<Kategorija>getParcelableArrayListExtra("azuriraneKategorije");
                    kategorije.clear();
                    kategorije.addAll(kat);
                    adapterZaSpinner.notifyDataSetChanged();


                    if (data.getIntExtra("pozicijaKliknutogKviza", -1) != kvizovi.size() - 1 && kvizovi.size() != 1) {
                        kvizovi.remove(pozicijaKliknutogKviza);
                        kvizovi.add(pozicijaKliknutogKviza, (Kviz) data.getParcelableExtra("noviKviz")); //uređivanje kviza
                        kvizovi.get(pozicijaKliknutogKviza).setPitanja(data.<Pitanje>getParcelableArrayListExtra("pitanja")); //ako je azuriranje
                    } else {

                        for (Kviz i : kvizovi) {
                            if (noviKviz.getNaziv().equalsIgnoreCase(i.getNaziv())) {
                                postojiLi = true;
                                Toast.makeText(getApplicationContext(), "Kviz pod tim imenom vec postoji", Toast.LENGTH_SHORT).show();
                                break;
                            }
                        }
                        if (postojiLi == false) {
                            noviKviz.setPitanja(data.<Pitanje>getParcelableArrayListExtra("pitanja"));
                            kvizovi.add(pozicijaKliknutogKviza, noviKviz);
                        }

                    }
                    spinner.setSelection(0);
                    adapterZaListuKvizova.notifyDataSetChanged();
                }
            }
        }
    }

    private class DajToken extends AsyncTask<String, Void, Void> {

        @Override
        protected Void doInBackground(String... strings) {
            GoogleCredential googleCredential;
            try {
                InputStream tajna = getResources().openRawResource(R.raw.secret);
                googleCredential = GoogleCredential.fromStream(tajna).createScoped(Lists.newArrayList("https://www.googleapis.com/auth/datastore"));

                googleCredential.refreshToken();
                TOKEN = googleCredential.getAccessToken();
                Log.d("TOKEN", TOKEN);
            } catch (IOException e) {
                e.printStackTrace();
            }
            return null;
        }
    }

    private class DobaviSveKategorije extends AsyncTask<String, Integer, ArrayList<Kategorija>>{

        @Override
        protected ArrayList<Kategorija> doInBackground(String... strings) {
            String url1 = "https://firestore.googleapis.com/v1/projects/spirala3-7ab31/databases/(default)/documents/" + strings[0] + "?access_token=" + TOKEN;

            try {
                URL url = new URL(url1);
                HttpURLConnection urlConnection = (HttpURLConnection) url.openConnection();
                InputStream in = new BufferedInputStream(urlConnection.getInputStream());
                String rezultat = convertStreamToString(in);
                JSONObject jo = null;
                jo = new JSONObject(rezultat);
                JSONArray items = new JSONArray();
                if (strings[0].equalsIgnoreCase("Kategorije")) {
                    items = jo.getJSONArray("documents");
                    ArrayList<Kategorija> kategorijeBaza = ucitajSveKategorijeIzBaze(items);
                    boolean postojiLi = false;
                    for (Kategorija p : kategorijeBaza) {
                        for (Kategorija k : kategorije) {
                            if (k.compareTo(p) == 0) postojiLi = true;
                        }
                        if (!postojiLi) kategorije.add(p);
                        postojiLi = false;
                    }
                }
            } catch (MalformedURLException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            } catch (JSONException e) {
                e.printStackTrace();
            }

            return null;
        }
    }

    public static ArrayList<Kategorija> ucitajSveKategorijeIzBaze(JSONArray items) {
        ArrayList<Kategorija> kategorijeIzBaze = new ArrayList<>();
        try {
            for(int i = 0; i < items.length(); i++) {
                JSONObject name = null;
                name = items.getJSONObject(i);
                kategorijeIzBaze.add(ucitajKategoriju(name));
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }
        return kategorijeIzBaze;
    }

    public static Kategorija ucitajKategoriju(JSONObject name) {
        JSONObject kategorija = null;
        try {
            kategorija = name.getJSONObject("fields");
            String naziv = kategorija.getJSONObject("naziv").getString("stringValue");
            String idIkonice = kategorija.getJSONObject("idIkonice").getString("integerValue");
            Kategorija kategorija1 = new Kategorija( naziv, idIkonice);
            return  kategorija1;
        } catch (JSONException e) {
            e.printStackTrace();
            return null;
        }
    }

    private class DobaviSveKvizove extends AsyncTask<String, Integer, ArrayList<Kviz>>{

        @Override
        protected void onPostExecute(ArrayList<Kviz> kvizs) {
            super.onPostExecute(kvizs);
            kvizovi.clear();
            kvizovi.addAll(kvizs);
            itemPLUS();
            adapterZaListuKvizova = new AdapterZaListuKvizova(KvizoviAkt.this, kvizovi, getResources());
            listaKvizova.setAdapter(adapterZaListuKvizova);
        }

        @Override
        protected ArrayList<Kviz> doInBackground(String... strings) {
            String url1 = "https://firestore.googleapis.com/v1/projects/spirala3-7ab31/databases/(default)/documents/" + strings[0] + "?access_token=" + TOKEN;
            ArrayList<Kviz> sviKvizovi = new ArrayList<>();
            try {
                URL url = new URL(url1);
                HttpURLConnection urlConnection = (HttpURLConnection) url.openConnection();
                InputStream in = new BufferedInputStream(urlConnection.getInputStream());
                String rezultat = convertStreamToString(in);
                JSONObject jo = null;
                jo = new JSONObject(rezultat);
                JSONArray items = new JSONArray();
                items = jo.getJSONArray("documents");
                sviKvizovi = ucitajKvizoveBaza(items);
                boolean postojiLi = false;
                for (Kviz p : sviKvizovi) {
                    for (Kviz k : kvizovi) {
                        if (k.compareTo(p) == 0) postojiLi = true;
                    }
                    if (!postojiLi) kvizovi.add(p);
                    postojiLi = false;
                }

            } catch (MalformedURLException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            } catch (JSONException e) {
                e.printStackTrace();
            }
            return sviKvizovi;
        }
    }

    private ArrayList<Kviz> ucitajKvizoveBaza(JSONArray items) {

        Kategorija trenutnaKategorija = null;
        ArrayList<Kviz> kvizoviIzBaze = new ArrayList<>();
        try {
            for(int i = 0; i < items.length(); i++) {
                JSONObject name = items.getJSONObject(i);
                JSONObject dokument = new JSONObject();
                JSONObject kviz = new JSONObject();
                kviz = name.getJSONObject("fields");
                String naziv = kviz.getJSONObject("naziv").getString("stringValue");
                String idKategorije = kviz.getJSONObject("idKategorije").getString("stringValue");
                ArrayList<String> pitanjaIdevi = new ArrayList<String>();
                JSONArray jArray = new JSONArray();
                try {
                    jArray =  kviz.getJSONObject("pitanja").getJSONObject("arrayValue").getJSONArray("values");
                } catch (JSONException e) {

                }
                for (int j = 0; j < jArray.length(); j++){
                    pitanjaIdevi.add(jArray.getJSONObject(j).getString("stringValue"));
                }

                for(Kategorija k : kategorije){
                    if(k.getNaziv().equalsIgnoreCase(idKategorije)){
                        trenutnaKategorija = k;
                    }
                }


                kvizoviIzBaze.add(new Kviz(naziv, dajOdgovarajucaPitanja(pitanjaIdevi), trenutnaKategorija));
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }

        return kvizoviIzBaze;
    }

    private ArrayList<Pitanje> dajOdgovarajucaPitanja(ArrayList<String> pitanjaIdevi) {
        ArrayList<Pitanje> pitanja = new ArrayList<>();
        for (String s : pitanjaIdevi) {
            for(Pitanje p : pitanjaBaza){
                if(p.getNaziv().equalsIgnoreCase(s)){
                    pitanja.add(p);
                    break;
                }
            }
        }
        return pitanja;
    }

    private class DobaviSvaPitanja extends AsyncTask<String, Integer, ArrayList<Pitanje>> {

        @Override
        protected void onPostExecute(ArrayList<Pitanje> pitanjes) {
            super.onPostExecute(pitanjes);
            pitanjaBaza.clear();
            pitanjaBaza.addAll(pitanjes);
        }

        @Override
        protected ArrayList<Pitanje> doInBackground(String... urls) {
            String url1;
            ArrayList<Pitanje> listaMogucih = new ArrayList<>();
            if (urls.length == 1)
                url1 = "https://firestore.googleapis.com/v1/projects/spirala3-7ab31/databases/(default)/documents/" + urls[0] + "?access_token=" + TOKEN;
            else
                url1 = "https://firestore.googleapis.com/v1/projects/spirala3-7ab31/databases/(default)/documents/" + urls[0] + "/" + urls[1] + "?access_token=" + TOKEN;
            URL url;

            try {
                url = new URL(url1);
                HttpURLConnection urlConnection = (HttpURLConnection) url.openConnection();
                InputStream in = new BufferedInputStream(urlConnection.getInputStream());
                String rezultat = convertStreamToString(in);
                JSONObject jo = null;
                jo = new JSONObject(rezultat);
                JSONArray items = new JSONArray();
                if (urls[0].equalsIgnoreCase("Pitanja")) {
                    items = jo.getJSONArray("documents");
                    ArrayList<Pitanje> ucitanaPitanja = DodajKvizAkt.ucitajSvaPitanjaIzBaze(items);
                    boolean postojiLi = false;
                    for (Pitanje p : ucitanaPitanja) {
                        for (Pitanje pitanje : pitanjaBaza) {
                            if (pitanje.compareTo(p) == 0) postojiLi = true;
                        }
                        if (!postojiLi) listaMogucih.add(p);
                        postojiLi = false;
                    }
                }
            } catch (MalformedURLException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            } catch (JSONException e) {
                e.printStackTrace();
            }
            return listaMogucih;
        }
    }

    private class DobaviSveKvizovePoKategoriji extends AsyncTask<String, Integer, ArrayList<Kviz>>{

        @Override
        protected void onPostExecute(ArrayList<Kviz> kvizs) {
            super.onPostExecute(kvizs);
            ArrayList<Kviz> pomocni = new ArrayList<>();
            kvizovi.clear();
            kvizovi.addAll(kvizs);
            itemPLUS();
            for (Kviz i : kvizovi) {
                if (i.getKategorija() == null || i.getKategorija().getId().equals(kategorija.getId()))
                    pomocni.add(i);
            }

            //itemPLUS();
            adapterZaListuKvizova = new AdapterZaListuKvizova(KvizoviAkt.this, pomocni, getResources());
            listaKvizova.setAdapter(adapterZaListuKvizova);
        }

        @Override
        protected ArrayList<Kviz> doInBackground(String... strings) {
            String url1 = "https://firestore.googleapis.com/v1/projects/spirala3-7ab31/databases/(default)/documents/" + strings[0] + "?access_token=" + TOKEN;
            ArrayList<Kviz> sviKvizovi = new ArrayList<>();
            try {
                URL url = new URL(url1);
                HttpURLConnection urlConnection = (HttpURLConnection) url.openConnection();
                InputStream in = new BufferedInputStream(urlConnection.getInputStream());
                String rezultat = convertStreamToString(in);
                JSONObject jo = null;
                jo = new JSONObject(rezultat);
                JSONArray items = new JSONArray();
                items = jo.getJSONArray("documents");
                sviKvizovi = ucitajKvizoveBaza(items);
                boolean postojiLi = false;
                for (Kviz p : sviKvizovi) {
                    for (Kviz k : kvizovi) {
                        if (k.compareTo(p) == 0) postojiLi = true;
                    }
                    if (!postojiLi) kvizovi.add(p);
                    postojiLi = false;
                }

            } catch (MalformedURLException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            } catch (JSONException e) {
                e.printStackTrace();
            }
            return sviKvizovi;
        }
    }

}
