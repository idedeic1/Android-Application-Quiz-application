package ba.unsa.etf.rma.fragmenti;



import android.content.Context;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import java.util.ArrayList;

import ba.unsa.etf.rma.R;
import ba.unsa.etf.rma.klase.Kviz;
import ba.unsa.etf.rma.klase.Pitanje;

public class InformacijeFrag extends Fragment {

    private InformacijeFragListener listener;
    private Button zavrsiKviz;
    private TextView imeKviza;
    private TextView brojTacnihPitanja;
    private TextView brojPreostalihPitanja;
    private TextView postotak;

    public interface InformacijeFragListener{
        void onInputBSent(CharSequence tacni, CharSequence preostali, CharSequence procenat);
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.informacija_fragment, container, false);

        Kviz kviz = (Kviz)getArguments().getParcelable("kviz");
        ArrayList<Pitanje> pitanja = new ArrayList<>(getArguments().<Pitanje>getParcelableArrayList("pitanja"));

        imeKviza = (TextView) v.findViewById(R.id.infNazivKviza);
        brojTacnihPitanja = (TextView) v.findViewById(R.id.infBrojTacnihPitanja);
        brojPreostalihPitanja = (TextView) v.findViewById(R.id.infBrojPreostalihPitanja);
        postotak = (TextView) v.findViewById(R.id.infProcenatTacni);
        zavrsiKviz = (Button) v.findViewById(R.id.btnKraj);

        imeKviza.setText(kviz.getNaziv());
        brojTacnihPitanja.setText("0");
        if(pitanja.size() == 0){
            brojPreostalihPitanja.setText("0");
        } else {
            brojPreostalihPitanja.setText(pitanja.size() - 1 + "");
        }
        postotak.setText("0.0%");

        zavrsiKviz.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getActivity().finish();
            }
        });
        return v;
    }

    public void updateEditText(CharSequence tacni, CharSequence preostali, CharSequence procenat){
        brojTacnihPitanja.setText(tacni);
        brojPreostalihPitanja.setText(preostali);

        String proc = procenat.toString();
        double pr = Double.parseDouble(proc);

        postotak.setText(String.format("%.2f", pr) + "%");
    }

    /*@Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if(context instanceof InformacijeFragListener){
            listener = (InformacijeFragListener) context;
        } else {
            throw new RuntimeException(context.toString() + " must implement FragmentAListener");
        }
    }

    @Override
    public void onDetach() {
        super.onDetach();
        listener = null;
    }*/
}
