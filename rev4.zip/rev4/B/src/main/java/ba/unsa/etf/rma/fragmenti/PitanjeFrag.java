package ba.unsa.etf.rma.fragmenti;


import android.content.Context;
import android.content.res.Resources;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.os.Handler;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.Collections;

import ba.unsa.etf.rma.R;
import ba.unsa.etf.rma.aktivnosti.IgrajKvizAkt;
import ba.unsa.etf.rma.klase.Kviz;
import ba.unsa.etf.rma.adapteri.ListaOdgovoriFragAdapter;
import ba.unsa.etf.rma.klase.Pitanje;


public class PitanjeFrag extends Fragment {

    private PitanjeFragListener listener;
    private TextView imePitanja, preostaloVrijeme;
    private ListView listaOdgovora;
    private ListaOdgovoriFragAdapter adapter;

    private ArrayList<Pitanje> pitanja;
    private ArrayList<String> odgovori;

    private Integer brojTacnih = 0;
    private Double postotakTacnih = 0.0;
    private Pitanje pitanje;
    private int indexPitanja = 0;
    private CountDownTimer countDownTimer;
    private long preostaloSekundi;

    public interface PitanjeFragListener {
        void onInputASent(CharSequence brojTacnihChar, CharSequence brojPreostalihChar, CharSequence postotakTacnihChar);
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.pitanje_fragment, container, false);

        Resources res = getResources();

        Kviz kviz = (Kviz)getArguments().getParcelable("kviz");
        pitanja = getArguments().<Pitanje>getParcelableArrayList("pitanja");


        imePitanja = (TextView) v.findViewById(R.id.tekstPitanja);
        preostaloVrijeme = (TextView) v.findViewById(R.id.preostaloVrijeme);
        preostaloVrijeme.setText("");
        listaOdgovora = (ListView) v.findViewById(R.id.odgovoriPitanja);


        if(pitanja.size() != 0) {
            preostaloSekundi = pitanja.size() * 30;
            preostaloVrijeme.setText("Imate " + preostaloSekundi + " sekundi za rjesavanje ovog kviza");
        }

        Handler handler = new Handler();
        handler.postDelayed(new Runnable() {
            public void run() {
                preostaloVrijeme.setText("");
            }
        }, 2000);


        Collections.shuffle(pitanja);

        if(pitanja.size() != 0) {
            pitanje = pitanja.get(indexPitanja);
            odgovori = pitanje.getOdgovori();
            imePitanja.setText(pitanje.getNaziv());

            adapter = new ListaOdgovoriFragAdapter(getActivity(), pitanja.get(0).getOdgovori(), res);
            listaOdgovora.setAdapter(adapter);
        } else {
            imePitanja.setText("Kviz nema pitanja!");
        }



        listaOdgovora.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                int pozicijaTacnog = pitanje.getOdgovori().indexOf(pitanje.getTacan());
                adapter.setPozicijaKliknutog(position);
                adapter.setPozicijaTacnog(pozicijaTacnog);
                if(position == pozicijaTacnog) brojTacnih++;
                adapter.notifyDataSetChanged();
                Handler handler = new Handler();
                handler.postDelayed(new Runnable() {
                    public void run() {

                        Integer preostali = pitanja.size() - 2 - indexPitanja;
                        if(preostali < 0) preostali++;
                        postotakTacnih = (brojTacnih.doubleValue() / (indexPitanja + 1)) * 100;

                        listener.onInputASent(brojTacnih.toString(), preostali.toString(), postotakTacnih.toString());

                        if(indexPitanja != pitanja.size() - 1) {
                            pitanje = pitanja.get(++indexPitanja);
                            odgovori.clear();
                            odgovori.addAll(pitanja.get(indexPitanja).getOdgovori());
                            imePitanja.setText(pitanje.getNaziv());
                        } else {
                            imePitanja.setText("Kviz je završen!");
                            odgovori.clear();
                            IgrajKvizAkt.am.cancel(IgrajKvizAkt.pendingIntent);
                        }
                        adapter.setPozicijaKliknutog(-1);
                        adapter.setPozicijaTacnog(-1);
                        adapter.notifyDataSetChanged();
                    }
                }, 2000);

            }
        });

        return v;
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if(context instanceof PitanjeFragListener){
            listener = (PitanjeFragListener) context;
        } else {
            throw new RuntimeException(context.toString() + " must implement PitanjeFragListener");
        }
    }

    @Override
    public void onDetach() {
        super.onDetach();
        listener = null;
    }

}
